// routes/adminRoutes.js
const express = require("express");
const router = express.Router();
const {
  getStats, getUsers, toggleUser, deleteUser, getPendingProperties,
} = require("../controllers/adminController");
const { protect, adminOnly } = require("../middleware/auth");

// All admin routes require authentication + admin role
router.use(protect, adminOnly);

router.get("/stats",                    getStats);
router.get("/users",                    getUsers);
router.patch("/users/:id/toggle",       toggleUser);
router.delete("/users/:id",             deleteUser);
router.get("/pending-properties",       getPendingProperties);

module.exports = router;
