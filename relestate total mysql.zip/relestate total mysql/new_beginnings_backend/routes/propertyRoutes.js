// routes/propertyRoutes.js
const express = require("express");
const router = express.Router();
const {
  getProperties, getFeatured, getRecommended,
  getPropertyById, createProperty, updateProperty,
  updateStatus, deleteProperty,
} = require("../controllers/propertyController");
const { protect, optionalAuth, adminOnly } = require("../middleware/auth");
const upload = require("../middleware/upload");

router.get("/featured",          getFeatured);
router.get("/recommended",       getRecommended);
router.get("/",                  optionalAuth, getProperties);
router.get("/:id",               optionalAuth, getPropertyById);
router.post("/",                 protect, upload.array("images", 10), createProperty);
router.put("/:id",               protect, updateProperty);
router.patch("/:id/status",      protect, adminOnly, updateStatus);
router.delete("/:id",            protect, adminOnly, deleteProperty);

module.exports = router;
