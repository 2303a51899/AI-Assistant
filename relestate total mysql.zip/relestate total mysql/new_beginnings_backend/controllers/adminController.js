// controllers/adminController.js
const pool = require("../config/db");

// GET /api/admin/stats
exports.getStats = async (req, res, next) => {
  try {
    const [[{ total_properties }]] = await pool.query("SELECT COUNT(*) AS total_properties FROM properties");
    const [[{ total_users }]] = await pool.query("SELECT COUNT(*) AS total_users FROM users");
    const [[{ total_enquiries }]] = await pool.query("SELECT COUNT(*) AS total_enquiries FROM enquiries");
    const [[{ new_enquiries }]] = await pool.query("SELECT COUNT(*) AS new_enquiries FROM enquiries WHERE status='new'");
    const [[{ pending_approvals }]] = await pool.query("SELECT COUNT(*) AS pending_approvals FROM properties WHERE status='pending'");
    const [[{ active_listings }]] = await pool.query("SELECT COUNT(*) AS active_listings FROM properties WHERE status='active'");
    const [[{ sold_listings }]] = await pool.query("SELECT COUNT(*) AS sold_listings FROM properties WHERE status='sold'");

    // New this week
    const [[{ new_props_week }]] = await pool.query(
      "SELECT COUNT(*) AS new_props_week FROM properties WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );
    const [[{ new_users_week }]] = await pool.query(
      "SELECT COUNT(*) AS new_users_week FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );

    res.json({
      success: true,
      stats: {
        total_properties, active_listings, sold_listings,
        total_users, total_enquiries, new_enquiries,
        pending_approvals, new_props_week, new_users_week,
      },
    });
  } catch (err) { next(err); }
};

// GET /api/admin/users
exports.getUsers = async (req, res, next) => {
  try {
    const { page = 1, per_page = 20, search, role } = req.query;
    const conditions = [];
    const params = [];
    if (search) {
      conditions.push("(first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like);
    }
    if (role) { conditions.push("role=?"); params.push(role); }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const limit = Math.min(Number(per_page), 100);
    const offset = (Math.max(Number(page), 1) - 1) * limit;

    const [[{ total }]] = await pool.query(`SELECT COUNT(*) AS total FROM users ${where}`, params);
    const [rows] = await pool.query(
      `SELECT id, first_name, last_name, email, phone, city, role, is_active, created_at
       FROM users ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    res.json({ success: true, total, users: rows });
  } catch (err) { next(err); }
};

// PATCH /api/admin/users/:id/toggle  — activate / deactivate
exports.toggleUser = async (req, res, next) => {
  try {
    const [rows] = await pool.query("SELECT id, is_active, role FROM users WHERE id=?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: "User not found" });
    if (rows[0].role === "admin") {
      return res.status(400).json({ success: false, message: "Cannot deactivate an admin account" });
    }
    const newStatus = rows[0].is_active ? 0 : 1;
    await pool.query("UPDATE users SET is_active=? WHERE id=?", [newStatus, req.params.id]);
    res.json({ success: true, message: newStatus ? "User activated" : "User deactivated" });
  } catch (err) { next(err); }
};

// DELETE /api/admin/users/:id
exports.deleteUser = async (req, res, next) => {
  try {
    const [rows] = await pool.query("SELECT id, role FROM users WHERE id=?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: "User not found" });
    if (rows[0].role === "admin") {
      return res.status(400).json({ success: false, message: "Cannot delete an admin account" });
    }
    await pool.query("DELETE FROM users WHERE id=?", [req.params.id]);
    res.json({ success: true, message: "User deleted successfully" });
  } catch (err) { next(err); }
};

// GET /api/admin/pending-properties
exports.getPendingProperties = async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT p.*, u.first_name, u.last_name, u.email AS owner_email
       FROM properties p
       LEFT JOIN users u ON u.id = p.owner_id
       WHERE p.status = 'pending'
       ORDER BY p.created_at DESC`
    );
    res.json({ success: true, properties: rows });
  } catch (err) { next(err); }
};
