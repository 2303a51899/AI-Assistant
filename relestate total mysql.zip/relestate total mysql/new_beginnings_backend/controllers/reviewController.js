// controllers/reviewController.js
const pool = require("../config/db");

// GET /api/reviews/testimonials  — homepage testimonials (no property_id)
exports.getTestimonials = async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM reviews WHERE property_id IS NULL ORDER BY created_at DESC LIMIT 6"
    );
    res.json({ success: true, reviews: rows });
  } catch (err) { next(err); }
};

// GET /api/reviews/:property_id
exports.getPropertyReviews = async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM reviews WHERE property_id=? ORDER BY created_at DESC",
      [req.params.property_id]
    );
    res.json({ success: true, reviews: rows });
  } catch (err) { next(err); }
};

// POST /api/reviews/:property_id  (auth required)
exports.createReview = async (req, res, next) => {
  try {
    const { rating, review_text, role_label } = req.body;
    if (!rating || !review_text) {
      return res.status(400).json({ success: false, message: "rating and review_text are required" });
    }
    if (rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: "rating must be between 1 and 5" });
    }

    const propId = req.params.property_id;
    const [prop] = await pool.query("SELECT id FROM properties WHERE id=?", [propId]);
    if (!prop.length) return res.status(404).json({ success: false, message: "Property not found" });

    const name = `${req.user.first_name} ${req.user.last_name}`;
    await pool.query(
      `INSERT INTO reviews (property_id, user_id, name, role_label, rating, review_text)
       VALUES (?,?,?,?,?,?)`,
      [propId, req.user.id, name, role_label || "Member", rating, review_text]
    );

    // Recalculate property rating
    const [[stats]] = await pool.query(
      "SELECT AVG(rating) AS avg_rating, COUNT(*) AS cnt FROM reviews WHERE property_id=?",
      [propId]
    );
    await pool.query(
      "UPDATE properties SET rating=?, review_count=? WHERE id=?",
      [parseFloat(stats.avg_rating).toFixed(2), stats.cnt, propId]
    );

    res.status(201).json({ success: true, message: "Review submitted successfully" });
  } catch (err) { next(err); }
};
