// controllers/propertyController.js
const pool = require("../config/db");

// ── Helpers ───────────────────────────────────────────────────
const attachAmenities = async (properties) => {
  if (!properties.length) return properties;
  const ids = properties.map((p) => p.id);
  const [rows] = await pool.query(
    `SELECT property_id, name FROM amenities WHERE property_id IN (${ids.map(() => "?").join(",")})`,
    ids
  );
  const map = {};
  rows.forEach((r) => {
    (map[r.property_id] = map[r.property_id] || []).push(r.name);
  });
  return properties.map((p) => ({ ...p, amenities: map[p.id] || [] }));
};

const attachImages = async (properties) => {
  if (!properties.length) return properties;
  const ids = properties.map((p) => p.id);
  const [rows] = await pool.query(
    `SELECT property_id, url, is_primary FROM property_images WHERE property_id IN (${ids.map(() => "?").join(",")})`,
    ids
  );
  const map = {};
  rows.forEach((r) => {
    (map[r.property_id] = map[r.property_id] || []).push({ url: r.url, is_primary: !!r.is_primary });
  });
  return properties.map((p) => ({ ...p, images: map[p.id] || [] }));
};

// ── GET /api/properties ───────────────────────────────────────
exports.getProperties = async (req, res, next) => {
  try {
    const {
      search, type, city, min_price, max_price, beds,
      area_min, area_max, badge, status = "active",
      sort = "newest", page = 1, per_page = 8,
    } = req.query;

    const conditions = ["p.status = ?"];
    const params = [status];

    if (search) {
      conditions.push("(p.title LIKE ? OR p.city LIKE ? OR p.locality LIKE ?)");
      const like = `%${search}%`;
      params.push(like, like, like);
    }
    if (type) { conditions.push("p.type = ?"); params.push(type); }
    if (city) { conditions.push("p.city LIKE ?"); params.push(`%${city}%`); }
    if (min_price) { conditions.push("p.price >= ?"); params.push(Number(min_price)); }
    if (max_price) { conditions.push("p.price <= ?"); params.push(Number(max_price)); }
    if (beds) {
      if (beds === "4+") { conditions.push("p.beds >= 4"); }
      else { conditions.push("p.beds = ?"); params.push(Number(beds)); }
    }
    if (area_min) { conditions.push("p.area >= ?"); params.push(Number(area_min)); }
    if (area_max) { conditions.push("p.area <= ?"); params.push(Number(area_max)); }
    if (badge) { conditions.push("p.badge = ?"); params.push(badge); }

    const where = conditions.join(" AND ");

    const orderMap = {
      newest:     "p.created_at DESC",
      "price-asc":"p.price ASC",
      "price-desc":"p.price DESC",
      area:       "p.area DESC",
      rating:     "p.rating DESC",
    };
    const orderBy = orderMap[sort] || "p.created_at DESC";

    const limit = Math.min(Number(per_page) || 8, 50);
    const offset = (Math.max(Number(page), 1) - 1) * limit;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM properties p WHERE ${where}`,
      params
    );

    const [rows] = await pool.query(
      `SELECT p.* FROM properties p WHERE ${where} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    let properties = await attachAmenities(rows);
    properties = await attachImages(properties);

    res.json({
      success: true,
      total,
      page: Number(page),
      per_page: limit,
      total_pages: Math.ceil(total / limit),
      properties,
    });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/properties/featured ─────────────────────────────
exports.getFeatured = async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM properties WHERE badge = 'featured' AND status = 'active' ORDER BY rating DESC LIMIT 6"
    );
    let props = await attachAmenities(rows);
    props = await attachImages(props);
    res.json({ success: true, properties: props });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/properties/recommended ──────────────────────────
exports.getRecommended = async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM properties WHERE status = 'active' ORDER BY rating DESC LIMIT 4"
    );
    let props = await attachAmenities(rows);
    props = await attachImages(props);
    res.json({ success: true, properties: props });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/properties/:id ───────────────────────────────────
exports.getPropertyById = async (req, res, next) => {
  try {
    const [rows] = await pool.query("SELECT * FROM properties WHERE id = ?", [req.params.id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Property not found" });
    }
    let [prop] = await attachAmenities(rows);
    [prop] = await attachImages([prop]);

    // Attach reviews
    const [reviews] = await pool.query(
      "SELECT * FROM reviews WHERE property_id = ? ORDER BY created_at DESC",
      [prop.id]
    );
    prop.reviews_list = reviews;

    res.json({ success: true, property: prop });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/properties ──────────────────────────────────────
exports.createProperty = async (req, res, next) => {
  try {
    const {
      title, type, price, area, beds, baths, city, locality,
      address, description, owner_name, owner_phone,
      badge, emoji, lat, lng, amenities = [],
    } = req.body;

    if (!title || !type || !price || !area || !city) {
      return res.status(400).json({ success: false, message: "title, type, price, area, city are required" });
    }

    const [result] = await pool.query(
      `INSERT INTO properties
        (title, type, price, area, beds, baths, city, locality, address, description,
         owner_name, owner_phone, owner_id, badge, emoji, lat, lng, status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        title, type, price, area, beds || 0, baths || 0,
        city, locality || null, address || null, description || null,
        owner_name || null, owner_phone || null, req.user.id,
        badge || "new", emoji || "🏠", lat || null, lng || null,
        req.user.role === "admin" ? "active" : "pending",
      ]
    );

    const propId = result.insertId;

    // Insert amenities
    if (Array.isArray(amenities) && amenities.length) {
      for (const name of amenities) {
        await pool.query("INSERT INTO amenities (property_id, name) VALUES (?,?)", [propId, name]);
      }
    }

    // Insert uploaded images
    if (req.files && req.files.length) {
      for (let i = 0; i < req.files.length; i++) {
        const url = `/uploads/${req.files[i].filename}`;
        await pool.query(
          "INSERT INTO property_images (property_id, url, is_primary) VALUES (?,?,?)",
          [propId, url, i === 0 ? 1 : 0]
        );
      }
    }

    res.status(201).json({
      success: true,
      message: req.user.role === "admin"
        ? "Property listed successfully"
        : "Property submitted — pending admin approval",
      property_id: propId,
    });
  } catch (err) {
    next(err);
  }
};

// ── PUT /api/properties/:id ───────────────────────────────────
exports.updateProperty = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query("SELECT * FROM properties WHERE id=?", [id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Property not found" });
    }
    const prop = rows[0];

    // Only owner or admin may edit
    if (req.user.role !== "admin" && prop.owner_id !== req.user.id) {
      return res.status(403).json({ success: false, message: "Not authorised to edit this property" });
    }

    const {
      title, type, price, area, beds, baths, city, locality,
      address, description, owner_name, owner_phone, badge, emoji, lat, lng, amenities,
    } = req.body;

    await pool.query(
      `UPDATE properties SET
         title=?, type=?, price=?, area=?, beds=?, baths=?,
         city=?, locality=?, address=?, description=?,
         owner_name=?, owner_phone=?, badge=?, emoji=?, lat=?, lng=?
       WHERE id=?`,
      [
        title || prop.title, type || prop.type,
        price || prop.price, area || prop.area,
        beds ?? prop.beds, baths ?? prop.baths,
        city || prop.city, locality || prop.locality,
        address || prop.address, description || prop.description,
        owner_name || prop.owner_name, owner_phone || prop.owner_phone,
        badge || prop.badge, emoji || prop.emoji,
        lat || prop.lat, lng || prop.lng, id,
      ]
    );

    // Replace amenities if provided
    if (Array.isArray(amenities)) {
      await pool.query("DELETE FROM amenities WHERE property_id=?", [id]);
      for (const name of amenities) {
        await pool.query("INSERT INTO amenities (property_id, name) VALUES (?,?)", [id, name]);
      }
    }

    res.json({ success: true, message: "Property updated successfully" });
  } catch (err) {
    next(err);
  }
};

// ── PATCH /api/properties/:id/status  (admin) ─────────────────
exports.updateStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const allowed = ["active", "pending", "sold", "rejected"];
    if (!allowed.includes(status)) {
      return res.status(400).json({ success: false, message: `Status must be one of: ${allowed.join(", ")}` });
    }
    await pool.query("UPDATE properties SET status=? WHERE id=?", [status, req.params.id]);
    res.json({ success: true, message: `Property status updated to '${status}'` });
  } catch (err) {
    next(err);
  }
};

// ── DELETE /api/properties/:id  (admin) ───────────────────────
exports.deleteProperty = async (req, res, next) => {
  try {
    const [rows] = await pool.query("SELECT id FROM properties WHERE id=?", [req.params.id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Property not found" });
    }
    await pool.query("DELETE FROM properties WHERE id=?", [req.params.id]);
    res.json({ success: true, message: "Property deleted successfully" });
  } catch (err) {
    next(err);
  }
};
