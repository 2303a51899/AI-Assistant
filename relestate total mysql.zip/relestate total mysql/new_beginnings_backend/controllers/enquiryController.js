// controllers/enquiryController.js
const pool = require("../config/db");

// POST /api/enquiries
exports.createEnquiry = async (req, res, next) => {
  try {
    const { property_id, name, email, phone, message } = req.body;
    if (!property_id || !name || !email) {
      return res.status(400).json({ success: false, message: "property_id, name and email are required" });
    }

    const [prop] = await pool.query("SELECT id FROM properties WHERE id=?", [property_id]);
    if (!prop.length) return res.status(404).json({ success: false, message: "Property not found" });

    const [result] = await pool.query(
      `INSERT INTO enquiries (property_id, user_id, name, email, phone, message)
       VALUES (?,?,?,?,?,?)`,
      [property_id, req.user?.id || null, name, email, phone || null, message || null]
    );

    res.status(201).json({
      success: true,
      message: "Enquiry sent! The owner will contact you soon.",
      enquiry_id: result.insertId,
    });
  } catch (err) { next(err); }
};

// GET /api/enquiries  (admin → all; user → own)
exports.getEnquiries = async (req, res, next) => {
  try {
    let query, params;
    if (req.user.role === "admin") {
      query = `
        SELECT e.*, p.title AS property_title, p.city AS property_city
        FROM enquiries e
        LEFT JOIN properties p ON p.id = e.property_id
        ORDER BY e.created_at DESC
      `;
      params = [];
    } else {
      query = `
        SELECT e.*, p.title AS property_title, p.city AS property_city
        FROM enquiries e
        LEFT JOIN properties p ON p.id = e.property_id
        WHERE e.user_id = ?
        ORDER BY e.created_at DESC
      `;
      params = [req.user.id];
    }
    const [rows] = await pool.query(query, params);
    res.json({ success: true, enquiries: rows });
  } catch (err) { next(err); }
};

// PATCH /api/enquiries/:id/status  (admin)
exports.updateEnquiryStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!["new", "read", "replied"].includes(status)) {
      return res.status(400).json({ success: false, message: "Status must be: new, read, or replied" });
    }
    await pool.query("UPDATE enquiries SET status=? WHERE id=?", [status, req.params.id]);
    res.json({ success: true, message: "Enquiry status updated" });
  } catch (err) { next(err); }
};
